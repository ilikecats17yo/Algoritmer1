import java.util.*;
public class ExchangeOfElements {
    List<Integer> A;
    int i,j;
    public void Swap(){
        i = 0;
        i = 2;
        A = new ArrayList<Integer>();
        for(int i = 0; i < 5; i++) {
            A.add(i);
        }
        System.out.println(A);
        Collections.swap(A,i,j);
        System.out.println(A);
    }
    public void Reverse(){
        A = new ArrayList<Integer>();
        for(int i = 0; i < 5; i++) {
            A.add(i);
        }
        System.out.println(A);
        Collections.reverse(A);
        System.out.println(A);
    }
}
