import java.text.DecimalFormat;
public class Distance {
    double x,y,d;
    public void dist(){
        x = 5.;
        y = 6.;
        d = Math.sqrt(Math.pow((x - 0.),2.) + Math.pow((y - 0.),2.));
        System.out.printf("Distance is: " + "%.3f", d);

    }
}
