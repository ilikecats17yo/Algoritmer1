
public class LongestPlateau {

    public int[] plateau(int[] A){

        return []
    }
}
