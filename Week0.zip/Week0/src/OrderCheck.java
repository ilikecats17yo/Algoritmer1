public class OrderCheck {
    int a,b,c;
    public boolean inorder(int a, int b, int c){
        if((a < b && b < c) ||(a > b && b > c)){
            return true;
        }
        else{
            return false;
        }
    }
}
