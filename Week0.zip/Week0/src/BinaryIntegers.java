public class BinaryIntegers {
    int x;
    public String bin(int x){
        StringBuilder sb = new StringBuilder();
        while(x>0){
            sb.append(x%2);
            x /=2;
        }
        return sb.reverse().toString();
    }
}
