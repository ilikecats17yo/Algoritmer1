public class MatrixMultiplication {
    public int[][] matrixMul(int[][] A, int[][] B){
        int rowsA = A.length;
        int columnsA = A[0].length;
        int columnsB = B[0].length;
        int[][] result = new int[rowsA][columnsB];
        for(int i = 0; i < rowsA; i++){
            for(int j = 0; j < columnsB; j++){
                for(int k = 0; k < columnsA; k++){
                    result[i][j] += A[i][k] * B[k][j];
                }
            }
        }
        return result;
    }
}
