import java.util.Random;
public class HeadrTails {
    int n;
    double p;
    Random rand = new Random();
    public String flip(int n, double p){
        StringBuilder sb = new StringBuilder();
    for(int i = 0; i < n; i++){
        double r = rand.nextDouble();
        if(r < p){
            sb.append("H ");
        }
        else{
            sb.append("T ");
        }
    }
        return sb.toString();
    }
}
