import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ChristmasPresents {
    public String JealousMeter(int A, int L, int O) {
        List<String> jealousSiblings = new ArrayList<>();
        if (L > A && O > A) {
            jealousSiblings.add("Anna");
        }
        if (A > L) {
            jealousSiblings.add("Laura");
        }
        if (A > O || L > O) {
            jealousSiblings.add("Oscar");
        }
        if (jealousSiblings.isEmpty()) {
            jealousSiblings.add("NONE");
        } else {
            Collections.sort(jealousSiblings);
        }
        return String.join(" ", jealousSiblings);
    }
}
