import java.util.Scanner;

public class Calculation {
        int a,b,c;
public void Sub(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter int a: ");
        a = scanner.nextInt();
        System.out.println("You entered " + a);
        System.out.println("Please enter int b: ");
        b = scanner.nextInt();
        System.out.println("You entered " + b);
        System.out.println("Calculating a-b...");
        c = a - b;
        System.out.println("Diff between two integers is: " + c);

    }


}


