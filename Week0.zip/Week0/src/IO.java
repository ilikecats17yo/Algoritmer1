import java.util.Scanner;
public class IO {
    String s,ss;

    public void Output(){
        s = "World";
        System.out.println("Hey World");
        //3.2
        System.out.println("Hey " + s);
    }
    public void interaction(){
        Scanner scanner = new Scanner(System.in);
        ss = scanner.nextLine();
        System.out.print("Hey " + ss);
    }
}
