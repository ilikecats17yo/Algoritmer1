
import java.util.*;
public class Cutoff {
    int A[] = {5,4,3,2,1};
    int k = 2;
    public void cutoff(){
        System.out.println("arr: " + Arrays.toString(A));
        System.out.println("k: " + k);
    for(int i = 0; i < A.length; i++){
        if(A[i] > k){
            A[i] = k;
        }
        }
    System.out.println("New arr: " + Arrays.toString(A));
    }
}
