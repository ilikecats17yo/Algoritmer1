public class Sum {
    int x,sum;
    public void Sum(){
        x = 10;
        for(int i = 1; i <= x; i++){
            sum += i;
        }
        System.out.print(sum);


    }
}
