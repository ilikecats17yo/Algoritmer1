import java.io.IOException;
import java.util.Scanner;

public class ThreeSort {
    int a, b, c;

    public void sort() throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("a: ");
        a = scanner.nextInt();
        System.out.println("b: ");
        b = scanner.nextInt();
        System.out.println("c: ");
        c = scanner.nextInt();
        /*
        if(Math.min(a,b) == a && Math.min(a,c) == a){
            if(Math.max(c,a) == c && Math.max(c,b) == c){
                System.out.println("a,b,c: " + a + " " + b + " " + c);
            }
        }
        else if(Math.min(a,b) == b && Math.min(b,c) == b){
            if(Math.max(c,a) == c && Math.max(c,b) == c){
                System.out.println("b,a,c: " + b + " " + a + " " + c);
            }
        }
        else if(Math.min(a,b) == a){
            System.out.println("c,a,b: " + c + " " + a + " " + b);
        }
        else if(Math.min(a,b) == b) {
            System.out.println("c,b,a: " + c + " " + b + " " + a);
        }
        else if(a == b && a == c){
            throw new IOException("ERROR INPUT");
        }
        in case of a = b = c returns sorted a,b,c: n0,n1,n2
         */
            if (a == b && b == c) {
                throw new IllegalArgumentException("Integers have same value");
            } else {
                int min = Math.min(a, Math.min(b, c));
                int max = Math.max(a, Math.max(b, c));
                System.out.println(min + " " + (a + b + c - min - max) + " " + max);
            }
        }
    }
