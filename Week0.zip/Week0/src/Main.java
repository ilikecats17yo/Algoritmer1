import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) throws IOException {
        /*
        Calculation calc = new Calculation();
        calc.Sub();

         Cutoff cut = new Cutoff();
        cut.cutoff();

        IO io = new IO();
       io.Output();
       io.interaction();

        Sum sum = new Sum();
        sum.Sum();

        OrderCheck order = new OrderCheck();
        System.out.println(order.inorder(1,2,3));
        System.out.println(order.inorder(3,2,1));
        System.out.println(order.inorder(3,3,3));

        ExchangeOfElements ex = new ExchangeOfElements();
        ex.Swap();
        ex.Reverse();

        Distance ds = new Distance();
        ds.dist();

         ThreeSort tsort = new ThreeSort();
        tsort.sort();

        Factorial fact = new Factorial();
        System.out.println(fact.fact(5));

        HeadrTails HT = new HeadrTails();
        System.out.println(HT.flip(10,0.5));

        BinaryIntegers BI = new BinaryIntegers();
        System.out.println(BI.bin(255));

        MatrixMultiplication matrix = new MatrixMultiplication();
        int A[][]={{1,1,1},{2,2,2},{3,3,3}};
        int B[][]={{1,1,1},{2,2,2},{3,3,3}};
        String r = Arrays.deepToString(matrix.matrixMul(A, B));
        System.out.println(r);

         Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        ChristmasPresents CP = new ChristmasPresents();
        System.out.println(CP.JealousMeter(a,b,c));
         */









    }
}